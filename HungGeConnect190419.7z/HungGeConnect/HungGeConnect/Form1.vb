﻿Imports System.Collections
Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading


Public Class ModbusConnect

    Private data As Byte()

    Private MBmaster As ModbusConnect
    Private tcpAsyCl As Socket
    Private tcpAsyClBuffer As Byte() = New Byte(2047) {}
    Private tcpSynCl As Socket
    Private tcpSynClBuffer As Byte() = New Byte(2047) {}

    Private Const fctReadInputRegister As Byte = 4
    Private Const fctWriteSingleCoil As Byte = 5
    Private Const fctReadWriteMultipleRegister As Byte = 23
    Private Const excSendFailt As Byte = 100
    Private Const excExceptionOffset As Byte = 128

    Public Const excIllegalFunction As Byte = 1
    Public Const excIllegalDataAdr As Byte = 2
    Public Const excIllegalDataVal As Byte = 3
    Public Const excSlaveDeviceFailure As Byte = 4
    Public Const excAck As Byte = 5
    Public Const excGatePathUnavailable As Byte = 10
    Public Const excExceptionNotConnected As Byte = 253
    Public Const excExceptionConnectionLost As Byte = 254
    Public Const excExceptionTimeout As Byte = 255

    Public Delegate Sub ExceptionData(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
    Public Event OnException As ExceptionData
    Public Delegate Sub ResponseData(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal data As Byte())
    Public Event OnResponseData As ResponseData

    Private Shared _timeout As UShort = 500
    Private Shared _connected As Boolean = False

    Public Sub connect(ByVal ip As String, ByVal port As UShort)
        Try
            Dim _ip As IPAddress
            If IPAddress.TryParse(ip, _ip) = False Then
                Dim hst As IPHostEntry = Dns.GetHostEntry(ip)
                ip = hst.AddressList(0).ToString()
            End If
            ' ----------------------------------------------------------------
            ' Connect asynchronous client
            tcpAsyCl = New Socket(IPAddress.Parse(ip).AddressFamily, SocketType.Stream, ProtocolType.Tcp)
            tcpAsyCl.Connect(New IPEndPoint(IPAddress.Parse(ip), port))
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, _timeout)
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, _timeout)
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1)
            ' ----------------------------------------------------------------
            '' Connect synchronous client
            'tcpSynCl = New Socket(IPAddress.Parse(ip).AddressFamily, SocketType.Stream, ProtocolType.Tcp)
            'tcpSynCl.Connect(New IPEndPoint(IPAddress.Parse(ip), port))
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, _timeout)
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, _timeout)
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1)
            _connected = True
        Catch [error] As System.IO.IOException
            _connected = False
            Throw ([error])
        End Try
    End Sub

    Public Sub New(ByVal ip As String, ByVal port As UShort)
        connect(ip, port)
    End Sub

    Private Sub Button_Read_Click(sender As Object, e As EventArgs) Handles Button_Read.Click
        Dim ID As UShort = 4
        Dim unit As Byte = Convert.ToByte(TextBox_Unit.Text)
        Dim StartAddress As UShort = ReadStartAdr()
        Dim Length As Byte = Convert.ToByte(TextBox_Size.Text)

        MBmaster.ReadInputRegister(ID, unit, StartAddress, Length)
    End Sub

    Private Function ReadStartAdr() As UShort
        ' Convert hex numbers into decimal
        If TextBox_RegAddress.Text.IndexOf("0x", 0, TextBox_RegAddress.Text.Length) = 0 Then
            Dim str As String = TextBox_RegAddress.Text.Replace("0x", "")
            Dim hex As UShort = Convert.ToUInt16(str, 16)
            Return hex
        Else
            Return Convert.ToUInt16(TextBox_RegAddress.Text)
        End If
    End Function

    Private Function CreateReadHeader(ByVal id As UShort, ByVal unit As Byte, ByVal startAddress As UShort, ByVal length As UShort, ByVal [function] As Byte) As Byte()
        Dim data As Byte() = New Byte(11) {}

        Dim _id As Byte() = BitConverter.GetBytes(CShort(id))
        data(0) = _id(1)
        ' Slave id high byte
        data(1) = _id(0)
        ' Slave id low byte
        data(5) = 6
        ' Message size
        data(6) = unit
        ' Slave address
        data(7) = [function]
        ' Function code
        Dim _adr As Byte() = BitConverter.GetBytes(CShort(IPAddress.HostToNetworkOrder(CShort(startAddress))))
        data(8) = _adr(0)
        ' Start address
        data(9) = _adr(1)
        ' Start address
        Dim _length As Byte() = BitConverter.GetBytes(CShort(IPAddress.HostToNetworkOrder(CShort(length))))
        data(10) = _length(0)
        ' Number of data to read
        data(11) = _length(1)
        ' Number of data to read
        Return data
    End Function

    Public Sub ReadInputRegister(ByVal id As UShort, ByVal unit As Byte, ByVal startAddress As UShort, ByVal numInputs As UShort)
        WriteAsyncData(CreateReadHeader(id, unit, startAddress, numInputs, fctReadInputRegister), id)
    End Sub

    Friend Sub CallException(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
        If (tcpAsyCl Is Nothing) OrElse (tcpSynCl Is Nothing) Then
            Return
        End If
        If exception = excExceptionConnectionLost Then
            tcpSynCl = Nothing
            tcpAsyCl = Nothing
        End If
        RaiseEvent OnException(id, unit, [function], exception)
    End Sub

    Private Sub OnSend(ByVal result As System.IAsyncResult)
        If result.IsCompleted = False Then
            CallException(&HFFFF, &HFF, &HFF, excSendFailt)
        End If
    End Sub

    Friend Shared Function SwapUInt16(ByVal inValue As UInt16) As UInt16
        Return CType(((inValue And &HFF00) >> 8) Or ((inValue And &HFF) << 8), UInt16)
    End Function

    Private Sub OnReceive(ByVal result As System.IAsyncResult)
        If result.IsCompleted = False Then
            CallException(&HFF, &HFF, &HFF, excExceptionConnectionLost)
        End If

        Dim id As UShort = SwapUInt16(BitConverter.ToUInt16(tcpAsyClBuffer, 0))
        Dim unit As Byte = tcpAsyClBuffer(6)
        Dim [function] As Byte = tcpAsyClBuffer(7)
        Dim data As Byte()

        ' ------------------------------------------------------------
        ' Write response data
        If ([function] >= fctWriteSingleCoil) AndAlso ([function] <> fctReadWriteMultipleRegister) Then
            data = New Byte(1) {}
            Array.Copy(tcpAsyClBuffer, 10, data, 0, 2)
        Else
            ' ------------------------------------------------------------
            ' Read response data
            data = New Byte(tcpAsyClBuffer(8) - 1) {}
            Array.Copy(tcpAsyClBuffer, 9, data, 0, tcpAsyClBuffer(8))
        End If
        ' ------------------------------------------------------------
        ' Response data is slave exception
        If [function] > excExceptionOffset Then
            [function] -= excExceptionOffset
            CallException(id, unit, [function], tcpAsyClBuffer(8))
            ' ------------------------------------------------------------
            ' Response data is regular data
        Else
            'ElseIf OnResponseData IsNot Nothing Then
            RaiseEvent OnResponseData(id, unit, [function], data)
        End If

    End Sub

    Private Sub WriteAsyncData(ByVal write_data As Byte(), ByVal id As UShort)
        If (tcpAsyCl IsNot Nothing) AndAlso (tcpAsyCl.Connected) Then
            Try
                tcpAsyCl.BeginSend(write_data, 0, write_data.Length, SocketFlags.None, New AsyncCallback(AddressOf OnSend), Nothing)
                tcpAsyCl.BeginReceive(tcpAsyClBuffer, 0, tcpAsyClBuffer.Length, SocketFlags.None, New AsyncCallback(AddressOf OnReceive), tcpAsyCl)
            Catch generatedExceptionName As SystemException
                CallException(id, write_data(6), write_data(7), excExceptionConnectionLost)
            End Try
        Else
            CallException(id, write_data(6), write_data(7), excExceptionConnectionLost)
        End If
    End Sub

    Private Sub Button_Connect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button_Connect.Click
        Try
            ' Create new modbus master and add event functions
            MBmaster = New ModbusConnect(TextBox_IP.Text, 502)
            'MBmaster.OnResponseData += New ModbusTCP.Master.ResponseData(AddressOf MBmaster_OnResponseData)
            'MBmaster.OnException += New ModbusTCP.Master.ExceptionData(AddressOf MBmaster_OnException)
            AddHandler MBmaster.OnResponseData, New ResponseData(AddressOf MBmaster_OnResponseData)
            AddHandler MBmaster.OnException, New ExceptionData(AddressOf MBmaster_OnException)

            ' Show additional fields, enable watchdog
            GrpExchange.Visible = True
            GrpData.Visible = True
        Catch [error] As SystemException
            MessageBox.Show([error].Message)
        End Try
    End Sub

    Private Sub MBmaster_OnResponseData(ByVal ID As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal values As Byte())
        ' ------------------------------------------------------------------
        ' Seperate calling threads
        If Me.InvokeRequired Then
            Me.BeginInvoke(New ResponseData(AddressOf MBmaster_OnResponseData), New Object() {ID, unit, [function], values})
            Return
        End If

        ' ------------------------------------------------------------------------
        ' Identify requested data
        Select Case ID
            'Case 1
            '    grpData.Text = "Read coils"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            'Case 2
            '    grpData.Text = "Read discrete inputs"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            'Case 3
            '    grpData.Text = "Read holding register"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            Case 4
                GrpData.Text = "Read input register"
                data = values
                ShowAs(Nothing, Nothing)
                Exit Select
                'Case 5
                '    grpData.Text = "Write single coil"
                '    Exit Select
                'Case 6
                '    grpData.Text = "Write multiple coils"
                '    Exit Select
                'Case 7
                '    grpData.Text = "Write single register"
                '    Exit Select
                'Case 8
                '    grpData.Text = "Write multiple register"
                '    Exit Select
        End Select
    End Sub

    Private Sub MBmaster_OnException(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
        Dim exc As String = "Modbus says error: "
        Select Case exception
            Case excIllegalFunction
                exc += "Illegal function!"
                Exit Select
            Case excIllegalDataAdr
                exc += "Illegal data adress!"
                Exit Select
            Case excIllegalDataVal
                exc += "Illegal data value!"
                Exit Select
            Case excSlaveDeviceFailure
                exc += "Slave device failure!"
                Exit Select
            Case excAck
                exc += "Acknoledge!"
                Exit Select
            Case excGatePathUnavailable
                exc += "Gateway path unavailbale!"
                Exit Select
            Case excExceptionTimeout
                exc += "Slave timed out!"
                Exit Select
            Case excExceptionConnectionLost
                exc += "Connection is lost!"
                Exit Select
            Case excExceptionNotConnected
                exc += "Not connected!"
                Exit Select
        End Select

        MessageBox.Show(exc, "Modbus slave exception")
    End Sub

    Private Sub ShowAs(ByVal sender As Object, ByVal e As System.EventArgs) Handles radBits.CheckedChanged, radBytes.CheckedChanged, radWord.CheckedChanged, radChar.CheckedChanged
        Dim rad As RadioButton
        If TypeOf sender Is RadioButton Then
            rad = DirectCast(sender, RadioButton)
            If rad.Checked = False Then
                Return
            End If
        End If

        Dim bits As Boolean() = New Boolean(0) {}
        Dim word As Integer() = New Integer(0) {}
        Dim _char As String() = New String(0) {}

        ' Convert data to selected data type
        If radBits.Checked = True Then
            Dim bitArray As New BitArray(data)
            bits = New Boolean(bitArray.Count - 1) {}
            bitArray.CopyTo(bits, 0)
        End If
        If radWord.Checked = True Or radChar.Checked Then
            If data.Length < 2 Then
                Return
            End If
            word = New Integer(data.Length \ 2 - 1) {}
            Dim x As Integer = 0
            While x < data.Length
                word(x \ 2) = data(x) * 256 + data(x + 1)
                x = x + 2
            End While
        End If
        'If radChar.Checked = True Then
        '    If data.Length < 2 Then
        '        Return
        '    End If
        '    _char = New String(data.Length \ 2 - 1) {}
        '    Dim x As Integer = 0
        '    While x < data.Length
        '        _char(x \ 2) = Chr(data(x) * 256 + data(x + 1))
        '        x = x + 2
        '    End While
        'End If

        ' ------------------------------------------------------------------------
        ' Put new data into text boxes
        For Each ctrl As Control In GrpData.Controls
            If TypeOf ctrl Is TextBox Then
                Dim x As Integer = Convert.ToInt16(ctrl.Tag)
                If radBits.Checked Then
                    If x <= bits.GetUpperBound(0) Then
                        ctrl.Text = Convert.ToByte(bits(x)).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radBytes.Checked Then
                    If x <= data.GetUpperBound(0) Then
                        ctrl.Text = data(x).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radWord.Checked Then
                    If x <= word.GetUpperBound(0) Then
                        ctrl.Text = word(x).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radChar.Checked Then
                    'If x <= _char.GetUpperBound(0) Then
                    '    ctrl.Text = _char(x).ToString()
                    '    ctrl.Visible = True
                    'Else
                    '    ctrl.Text = ""
                    'End If
                    If x <= word.GetUpperBound(0) Then
                        ctrl.Text = Chr(word(x)).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
            End If
        Next
    End Sub
End Class
