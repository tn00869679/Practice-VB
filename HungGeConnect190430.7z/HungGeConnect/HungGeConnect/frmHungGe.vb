﻿Imports System.Collections
Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading
Imports HungGeConnect.Communication


Public Class ModbusConnect

    Private MBmaster As Communication
    Private data As Byte()
    Private txtData As TextBox
    Private labData As Label


    Private Sub frmHungGe_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set standard format byte, make some textboxes
        radBytes.Checked = False
        data = New Byte(-1) {}
    End Sub

    Private Sub frmHungGe_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If MBmaster IsNot Nothing Then
            MBmaster.Dispose()
            MBmaster = Nothing
        End If
        Application.[Exit]()
    End Sub

    Private Sub Button_Read_Click(sender As Object, e As EventArgs) Handles Button_Read.Click
        Dim ID As UShort = 4
        Dim unit As Byte = Convert.ToByte(TextBox_Unit.Text)
        Dim StartAddress As UShort = ReadStartAdr()
        Dim Length As Byte = Convert.ToByte(TextBox_Size.Text)

        MBmaster.ReadInputRegister(ID, unit, StartAddress, Length)
    End Sub

    Private Sub Button_Run_Click(sender As Object, e As EventArgs) Handles Button_Run.Click
        Try


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Function ReadStartAdr() As UShort
        ' Convert hex numbers into decimal
        If TextBox_RegAddress.Text.IndexOf("0x", 0, TextBox_RegAddress.Text.Length) = 0 Then
            Dim str As String = TextBox_RegAddress.Text.Replace("0x", "")
            Dim hex As UShort = Convert.ToUInt16(str, 16)
            Return hex
        Else
            Return Convert.ToUInt16(TextBox_RegAddress.Text)
        End If
    End Function

    Private Sub Button_Connect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button_Connect.Click
        Try
            If Button_Connect.BackColor = Color.GreenYellow Then
                Button_Connect.BackColor = Color.LightPink
                Button_Connect.Text = "Disconnect"
                ' Create new modbus master and add event functions
                MBmaster = New Communication(TextBox_IP.Text, 502)
                'MBmaster.OnResponseData += New ModbusTCP.Master.ResponseData(AddressOf MBmaster_OnResponseData)
                'MBmaster.OnException += New ModbusTCP.Master.ExceptionData(AddressOf MBmaster_OnException)
                AddHandler MBmaster.OnResponseData, New ResponseData(AddressOf MBmaster_OnResponseData)
                AddHandler MBmaster.OnException, New ExceptionData(AddressOf MBmaster_OnException)

                ResizeData()
                ' Show additional fields, enable watchdog
                GrpExchange.Visible = True
                GrpData.Visible = True
            Else
                Button_Connect.BackColor = Color.GreenYellow
                Button_Connect.Text = "Connect"
                MBmaster.Dispose()
                MBmaster = Nothing
                GrpData.Controls.Clear()
                GrpExchange.Visible = False
                GrpData.Visible = False
                radWord.Checked = False
            End If
        Catch [error] As SystemException
            MessageBox.Show([error].Message)
        End Try
    End Sub

    Private Sub MBmaster_OnResponseData(ByVal ID As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal values As Byte())
        ' ------------------------------------------------------------------
        ' Seperate calling threads
        If Me.InvokeRequired Then
            Me.BeginInvoke(New ResponseData(AddressOf MBmaster_OnResponseData), New Object() {ID, unit, [function], values})
            Return
        End If

        ' ------------------------------------------------------------------------
        ' Identify requested data
        Select Case ID
            'Case 1
            '    grpData.Text = "Read coils"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            'Case 2
            '    grpData.Text = "Read discrete inputs"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            'Case 3
            '    grpData.Text = "Read holding register"
            '    Data = values
            '    ShowAs(Nothing, Nothing)
            '    Exit Select
            Case 4
                GrpData.Text = "Read input register"
                data = values
                ShowAs(Nothing, Nothing)
                Exit Select
                'Case 5
                '    grpData.Text = "Write single coil"
                '    Exit Select
                'Case 6
                '    grpData.Text = "Write multiple coils"
                '    Exit Select
                'Case 7
                '    grpData.Text = "Write single register"
                '    Exit Select
                'Case 8
                '    grpData.Text = "Write multiple register"
                '    Exit Select
        End Select
    End Sub

    Private Sub MBmaster_OnException(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
        Dim exc As String = "Modbus says error: "
        Select Case exception
            Case excIllegalFunction
                exc += "Illegal function!"
                Exit Select
            Case excIllegalDataAdr
                exc += "Illegal data adress!"
                Exit Select
            Case excIllegalDataVal
                exc += "Illegal data value!"
                Exit Select
            Case excSlaveDeviceFailure
                exc += "Slave device failure!"
                Exit Select
            Case excAck
                exc += "Acknoledge!"
                Exit Select
            Case excGatePathUnavailable
                exc += "Gateway path unavailbale!"
                Exit Select
            Case excExceptionTimeout
                exc += "Slave timed out!"
                Exit Select
            Case excExceptionConnectionLost
                exc += "Connection is lost!"
                Exit Select
            Case excExceptionNotConnected
                exc += "Not connected!"
                Exit Select
        End Select

        MessageBox.Show(exc, "Modbus slave exception")
    End Sub

    Private Sub ResizeData()
        ' Create as many textboxes as fit into window
        GrpData.Controls.Clear()
        Dim x As Integer = 0
        Dim y As Integer = 10
        Dim z As Integer = 20
        While y < GrpData.Size.Width - 100
            labData = New Label()
            GrpData.Controls.Add(labData)
            labData.Size = New System.Drawing.Size(30, 20)
            labData.Location = New System.Drawing.Point(y, z)
            labData.Text = Convert.ToString(x + 1)

            txtData = New TextBox()
            GrpData.Controls.Add(txtData)
            txtData.Size = New System.Drawing.Size(50, 20)
            txtData.Location = New System.Drawing.Point(y + 30, z)
            txtData.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            txtData.Tag = x

            x += 1
            z = z + txtData.Size.Height + 5
            If z > GrpData.Size.Height - 40 Then
                y = y + 100
                z = 20
            End If
        End While
    End Sub

    Private Sub frmHungGe_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
        If GrpData.Visible = True Then
            ResizeData()
        End If
    End Sub

    Private Function GetData(ByVal num As Integer) As Byte()
        Dim bits As Boolean() = New Boolean(num - 1) {}
        Dim data As Byte() = New [Byte](num - 1) {}
        Dim word As Integer() = New Integer(num - 1) {}

        ' ------------------------------------------------------------------------
        ' Convert data from text boxes
        For Each ctrl As Control In GrpData.Controls
            If TypeOf ctrl Is TextBox Then
                Dim x As Integer = Convert.ToInt16(ctrl.Tag)
                If radBits.Checked Then
                    If (x <= bits.GetUpperBound(0)) AndAlso (ctrl.Text <> "") Then
                        bits(x) = Convert.ToBoolean(Convert.ToByte(ctrl.Text))
                    Else
                        Exit For
                    End If
                End If
                If radBytes.Checked Then
                    If (x <= data.GetUpperBound(0)) AndAlso (ctrl.Text <> "") Then
                        data(x) = Convert.ToByte(ctrl.Text)
                    Else
                        Exit For
                    End If
                End If
                If radWord.Checked Then
                    If (x <= data.GetUpperBound(0)) AndAlso (ctrl.Text <> "") Then
                        Try
                            word(x) = Convert.ToInt16(ctrl.Text)
                        Catch generatedExceptionName As SystemException
                            word(x) = Convert.ToUInt16(ctrl.Text)
                        End Try


                    Else
                        Exit For
                    End If
                End If
            End If
        Next
        If radBits.Checked Then
            Dim numBytes As Integer = CByte(num \ 8 + (If(num Mod 8 > 0, 1, 0)))
            data = New [Byte](numBytes - 1) {}
            Dim bitArray As New BitArray(bits)
            bitArray.CopyTo(data, 0)
        End If
        If radWord.Checked Or radChar.Checked Then
            data = New [Byte](num * 2 - 1) {}
            For x As Integer = 0 To num - 1
                Dim dat As Byte() = BitConverter.GetBytes(CShort(IPAddress.HostToNetworkOrder(CShort(word(x)))))
                data(x * 2) = dat(0)
                data(x * 2 + 1) = dat(1)
            Next
        End If
        Return data
    End Function

    Private Sub ShowAs(ByVal sender As Object, ByVal e As System.EventArgs) Handles radBits.CheckedChanged, radBytes.CheckedChanged, radWord.CheckedChanged, radChar.CheckedChanged
        Dim rad As RadioButton
        If TypeOf sender Is RadioButton Then
            rad = DirectCast(sender, RadioButton)
            If rad.Checked = False Then
                Return
            End If
        End If

        Dim bits As Boolean() = New Boolean(0) {}
        Dim word As Integer() = New Integer(0) {}
        Dim _char As String() = New String(0) {}

        ' Convert data to selected data type
        If radBits.Checked = True Then
            Dim bitArray As New BitArray(data)
            bits = New Boolean(bitArray.Count - 1) {}
            bitArray.CopyTo(bits, 0)
        End If
        If radWord.Checked = True Or radChar.Checked Then
            If data.Length < 2 Then
                Return
            End If
            word = New Integer(data.Length \ 2 - 1) {}
            Dim x As Integer = 0
            While x < data.Length
                word(x \ 2) = data(x) * 256 + data(x + 1)
                x = x + 2
            End While
        End If
        'If radChar.Checked = True Then
        '    If data.Length < 2 Then
        '        Return
        '    End If
        '    _char = New String(data.Length \ 2 - 1) {}
        '    Dim x As Integer = 0
        '    While x < data.Length
        '        _char(x \ 2) = Chr(data(x) * 256 + data(x + 1))
        '        x = x + 2
        '    End While
        'End If

        ' ------------------------------------------------------------------------
        ' Put new data into text boxes
        For Each ctrl As Control In GrpData.Controls
            If TypeOf ctrl Is TextBox Then
                Dim x As Integer = Convert.ToInt16(ctrl.Tag)
                If radBits.Checked Then
                    If x <= bits.GetUpperBound(0) Then
                        ctrl.Text = Convert.ToByte(bits(x)).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radBytes.Checked Then
                    If x <= data.GetUpperBound(0) Then
                        ctrl.Text = data(x).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radWord.Checked Then
                    If x <= word.GetUpperBound(0) Then
                        ctrl.Text = word(x).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
                If radChar.Checked Then
                    'If x <= _char.GetUpperBound(0) Then
                    '    ctrl.Text = _char(x).ToString()
                    '    ctrl.Visible = True
                    'Else
                    '    ctrl.Text = ""
                    'End If
                    If x <= word.GetUpperBound(0) Then
                        ctrl.Text = Chr(word(x)).ToString()
                        ctrl.Visible = True
                    Else
                        ctrl.Text = ""
                    End If
                End If
            End If
        Next
    End Sub
End Class
