﻿Imports System.Collections
Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

Public Class Communication

    Private Const fctReadInputRegister As Byte = 4
    Private Const fctWriteSingleCoil As Byte = 5
    Private Const fctReadWriteMultipleRegister As Byte = 23
    Private Const excSendFailt As Byte = 100
    Private Const excExceptionOffset As Byte = 128

    Public Const excIllegalFunction As Byte = 1
    Public Const excIllegalDataAdr As Byte = 2
    Public Const excIllegalDataVal As Byte = 3
    Public Const excSlaveDeviceFailure As Byte = 4
    Public Const excAck As Byte = 5
    Public Const excGatePathUnavailable As Byte = 10
    Public Const excExceptionNotConnected As Byte = 253
    Public Const excExceptionConnectionLost As Byte = 254
    Public Const excExceptionTimeout As Byte = 255

    Private tcpAsyCl As Socket
    Private tcpAsyClBuffer As Byte() = New Byte(2047) {}
    Private tcpSynCl As Socket
    Private tcpSynClBuffer As Byte() = New Byte(2047) {}


    Public Delegate Sub ExceptionData(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
    Public Event OnException As ExceptionData
    Public Delegate Sub ResponseData(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal data As Byte())
    Public Event OnResponseData As ResponseData

    Private Shared _timeout As UShort = 500
    Private Shared _connected As Boolean = False


    ' ------------------------------------------------------------------------
    ''' <summary>Shows if a connection is active.</summary>
    Public ReadOnly Property connected() As Boolean
        Get
            Return _connected
        End Get
    End Property

    ' ------------------------------------------------------------------------

    Public Sub New(ByVal ip As String, ByVal port As UShort)
        connect(ip, port)
    End Sub

    Public Sub connect(ByVal ip As String, ByVal port As UShort)
        Try
            Dim _ip As IPAddress
            If IPAddress.TryParse(ip, _ip) = False Then
                Dim hst As IPHostEntry = Dns.GetHostEntry(ip)
                ip = hst.AddressList(0).ToString()
            End If
            ' ----------------------------------------------------------------
            ' Connect asynchronous client
            tcpAsyCl = New Socket(IPAddress.Parse(ip).AddressFamily, SocketType.Stream, ProtocolType.Tcp)
            tcpAsyCl.Connect(New IPEndPoint(IPAddress.Parse(ip), port))
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, _timeout)
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, _timeout)
            tcpAsyCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1)
            ' ----------------------------------------------------------------
            '' Connect synchronous client
            'tcpSynCl = New Socket(IPAddress.Parse(ip).AddressFamily, SocketType.Stream, ProtocolType.Tcp)
            'tcpSynCl.Connect(New IPEndPoint(IPAddress.Parse(ip), port))
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, _timeout)
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, _timeout)
            'tcpSynCl.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1)
            _connected = True
        Catch [error] As System.IO.IOException
            _connected = False
            Throw ([error])
        End Try
    End Sub

    Public Sub Dispose()
        If tcpAsyCl IsNot Nothing Then
            If tcpAsyCl.Connected Then
                Try
                    tcpAsyCl.Shutdown(SocketShutdown.Both)
                Catch
                End Try
                tcpAsyCl.Close()
            End If
            tcpAsyCl = Nothing
        End If
        If tcpSynCl IsNot Nothing Then
            If tcpSynCl.Connected Then
                Try
                    tcpSynCl.Shutdown(SocketShutdown.Both)
                Catch
                End Try
                tcpSynCl.Close()
            End If
            tcpSynCl = Nothing
        End If
    End Sub

    Friend Sub CallException(ByVal id As UShort, ByVal unit As Byte, ByVal [function] As Byte, ByVal exception As Byte)
        If (tcpAsyCl Is Nothing) OrElse (tcpSynCl Is Nothing) Then
            Return
        End If
        If exception = excExceptionConnectionLost Then
            tcpSynCl = Nothing
            tcpAsyCl = Nothing
        End If
        RaiseEvent OnException(id, unit, [function], exception)
    End Sub

    Friend Shared Function SwapUInt16(ByVal inValue As UInt16) As UInt16
        Return CType(((inValue And &HFF00) >> 8) Or ((inValue And &HFF) << 8), UInt16)
    End Function

    Public Sub ReadInputRegister(ByVal id As UShort, ByVal unit As Byte, ByVal startAddress As UShort, ByVal numInputs As UShort)
        WriteAsyncData(CreateReadHeader(id, unit, startAddress, numInputs, fctReadInputRegister), id)
    End Sub

    Private Function CreateReadHeader(ByVal id As UShort, ByVal unit As Byte, ByVal startAddress As UShort, ByVal length As UShort, ByVal [function] As Byte) As Byte()
        Dim data As Byte() = New Byte(11) {}

        Dim _id As Byte() = BitConverter.GetBytes(CShort(id))
        data(0) = _id(1)
        ' Slave id high byte
        data(1) = _id(0)
        ' Slave id low byte
        data(5) = 6
        ' Message size
        data(6) = unit
        ' Slave address
        data(7) = [function]
        ' Function code
        Dim _adr As Byte() = BitConverter.GetBytes(CShort(IPAddress.HostToNetworkOrder(CShort(startAddress))))
        data(8) = _adr(0)
        ' Start address
        data(9) = _adr(1)
        ' Start address
        Dim _length As Byte() = BitConverter.GetBytes(CShort(IPAddress.HostToNetworkOrder(CShort(length))))
        data(10) = _length(0)
        ' Number of data to read
        data(11) = _length(1)
        ' Number of data to read
        Return data
    End Function

    Private Sub WriteAsyncData(ByVal write_data As Byte(), ByVal id As UShort)
        If (tcpAsyCl IsNot Nothing) AndAlso (tcpAsyCl.Connected) Then
            Try
                tcpAsyCl.BeginSend(write_data, 0, write_data.Length, SocketFlags.None, New AsyncCallback(AddressOf OnSend), Nothing)
                tcpAsyCl.BeginReceive(tcpAsyClBuffer, 0, tcpAsyClBuffer.Length, SocketFlags.None, New AsyncCallback(AddressOf OnReceive), tcpAsyCl)
            Catch generatedExceptionName As SystemException
                CallException(id, write_data(6), write_data(7), excExceptionConnectionLost)
            End Try
        Else
            CallException(id, write_data(6), write_data(7), excExceptionConnectionLost)
        End If
    End Sub

    Private Sub OnSend(ByVal result As System.IAsyncResult)
        If result.IsCompleted = False Then
            CallException(&HFFFF, &HFF, &HFF, excSendFailt)
        End If
    End Sub

    Private Sub OnReceive(ByVal result As System.IAsyncResult)
        If result.IsCompleted = False Then
            CallException(&HFF, &HFF, &HFF, excExceptionConnectionLost)
        End If

        Dim id As UShort = SwapUInt16(BitConverter.ToUInt16(tcpAsyClBuffer, 0))
        Dim unit As Byte = tcpAsyClBuffer(6)
        Dim [function] As Byte = tcpAsyClBuffer(7)
        Dim data As Byte()

        ' ------------------------------------------------------------
        ' Write response data
        If ([function] >= fctWriteSingleCoil) AndAlso ([function] <> fctReadWriteMultipleRegister) Then
            data = New Byte(1) {}
            Array.Copy(tcpAsyClBuffer, 10, data, 0, 2)
        Else
            ' ------------------------------------------------------------
            ' Read response data
            data = New Byte(tcpAsyClBuffer(8) - 1) {}
            Array.Copy(tcpAsyClBuffer, 9, data, 0, tcpAsyClBuffer(8))
        End If
        ' ------------------------------------------------------------
        ' Response data is slave exception
        If [function] > excExceptionOffset Then
            [function] -= excExceptionOffset
            CallException(id, unit, [function], tcpAsyClBuffer(8))
            ' ------------------------------------------------------------
            ' Response data is regular data
        Else
            'ElseIf OnResponseData IsNot Nothing Then
            RaiseEvent OnResponseData(id, unit, [function], data)
        End If

    End Sub

End Class
