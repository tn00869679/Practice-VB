﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModbusConnect
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox_IP = New System.Windows.Forms.TextBox()
        Me.Label_IP = New System.Windows.Forms.Label()
        Me.TextBox_ID = New System.Windows.Forms.TextBox()
        Me.Label_ID = New System.Windows.Forms.Label()
        Me.TextBox_RegAddress = New System.Windows.Forms.TextBox()
        Me.Label_RegAddress = New System.Windows.Forms.Label()
        Me.Button_Read = New System.Windows.Forms.Button()
        Me.Button_Run = New System.Windows.Forms.Button()
        Me.TextBox_Size = New System.Windows.Forms.TextBox()
        Me.Label_Size = New System.Windows.Forms.Label()
        Me.Button_Connect = New System.Windows.Forms.Button()
        Me.TextBox_Unit = New System.Windows.Forms.TextBox()
        Me.Label_Unit = New System.Windows.Forms.Label()
        Me.GrpExchange = New System.Windows.Forms.GroupBox()
        Me.GrpShowAs = New System.Windows.Forms.GroupBox()
        Me.radChar = New System.Windows.Forms.RadioButton()
        Me.radBits = New System.Windows.Forms.RadioButton()
        Me.radWord = New System.Windows.Forms.RadioButton()
        Me.radBytes = New System.Windows.Forms.RadioButton()
        Me.GrpComm = New System.Windows.Forms.GroupBox()
        Me.GrpData = New System.Windows.Forms.GroupBox()
        Me.GrpExchange.SuspendLayout()
        Me.GrpShowAs.SuspendLayout()
        Me.GrpComm.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox_IP
        '
        Me.TextBox_IP.Location = New System.Drawing.Point(34, 21)
        Me.TextBox_IP.Name = "TextBox_IP"
        Me.TextBox_IP.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_IP.Size = New System.Drawing.Size(141, 22)
        Me.TextBox_IP.TabIndex = 0
        '
        'Label_IP
        '
        Me.Label_IP.AutoSize = True
        Me.Label_IP.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_IP.Location = New System.Drawing.Point(7, 21)
        Me.Label_IP.Name = "Label_IP"
        Me.Label_IP.Size = New System.Drawing.Size(21, 16)
        Me.Label_IP.TabIndex = 1
        Me.Label_IP.Text = "IP"
        '
        'TextBox_ID
        '
        Me.TextBox_ID.Location = New System.Drawing.Point(212, 21)
        Me.TextBox_ID.Name = "TextBox_ID"
        Me.TextBox_ID.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_ID.Size = New System.Drawing.Size(95, 22)
        Me.TextBox_ID.TabIndex = 2
        Me.TextBox_ID.Text = "1"
        '
        'Label_ID
        '
        Me.Label_ID.AutoSize = True
        Me.Label_ID.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_ID.Location = New System.Drawing.Point(182, 21)
        Me.Label_ID.Name = "Label_ID"
        Me.Label_ID.Size = New System.Drawing.Size(24, 16)
        Me.Label_ID.TabIndex = 3
        Me.Label_ID.Text = "ID"
        '
        'TextBox_RegAddress
        '
        Me.TextBox_RegAddress.Location = New System.Drawing.Point(206, 84)
        Me.TextBox_RegAddress.Name = "TextBox_RegAddress"
        Me.TextBox_RegAddress.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_RegAddress.Size = New System.Drawing.Size(100, 22)
        Me.TextBox_RegAddress.TabIndex = 4
        Me.TextBox_RegAddress.Text = "0"
        '
        'Label_RegAddress
        '
        Me.Label_RegAddress.AutoSize = True
        Me.Label_RegAddress.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_RegAddress.Location = New System.Drawing.Point(122, 84)
        Me.Label_RegAddress.Name = "Label_RegAddress"
        Me.Label_RegAddress.Size = New System.Drawing.Size(84, 16)
        Me.Label_RegAddress.TabIndex = 5
        Me.Label_RegAddress.Text = "RegAddress"
        '
        'Button_Read
        '
        Me.Button_Read.Location = New System.Drawing.Point(322, 51)
        Me.Button_Read.Name = "Button_Read"
        Me.Button_Read.Size = New System.Drawing.Size(73, 42)
        Me.Button_Read.TabIndex = 6
        Me.Button_Read.Text = "Read"
        Me.Button_Read.UseVisualStyleBackColor = True
        '
        'Button_Run
        '
        Me.Button_Run.Location = New System.Drawing.Point(322, 99)
        Me.Button_Run.Name = "Button_Run"
        Me.Button_Run.Size = New System.Drawing.Size(73, 42)
        Me.Button_Run.TabIndex = 6
        Me.Button_Run.Text = "Run"
        Me.Button_Run.UseVisualStyleBackColor = True
        '
        'TextBox_Size
        '
        Me.TextBox_Size.Location = New System.Drawing.Point(206, 112)
        Me.TextBox_Size.Name = "TextBox_Size"
        Me.TextBox_Size.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_Size.Size = New System.Drawing.Size(100, 22)
        Me.TextBox_Size.TabIndex = 7
        Me.TextBox_Size.Text = "20"
        '
        'Label_Size
        '
        Me.Label_Size.AutoSize = True
        Me.Label_Size.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_Size.Location = New System.Drawing.Point(172, 112)
        Me.Label_Size.Name = "Label_Size"
        Me.Label_Size.Size = New System.Drawing.Size(34, 16)
        Me.Label_Size.TabIndex = 8
        Me.Label_Size.Text = "Size"
        '
        'Button_Connect
        '
        Me.Button_Connect.BackColor = System.Drawing.Color.GreenYellow
        Me.Button_Connect.Location = New System.Drawing.Point(322, 21)
        Me.Button_Connect.Name = "Button_Connect"
        Me.Button_Connect.Size = New System.Drawing.Size(85, 22)
        Me.Button_Connect.TabIndex = 9
        Me.Button_Connect.Text = "Connect"
        Me.Button_Connect.UseVisualStyleBackColor = False
        '
        'TextBox_Unit
        '
        Me.TextBox_Unit.Location = New System.Drawing.Point(206, 56)
        Me.TextBox_Unit.Name = "TextBox_Unit"
        Me.TextBox_Unit.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_Unit.Size = New System.Drawing.Size(100, 22)
        Me.TextBox_Unit.TabIndex = 4
        Me.TextBox_Unit.Text = "0"
        '
        'Label_Unit
        '
        Me.Label_Unit.AutoSize = True
        Me.Label_Unit.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_Unit.Location = New System.Drawing.Point(170, 56)
        Me.Label_Unit.Name = "Label_Unit"
        Me.Label_Unit.Size = New System.Drawing.Size(35, 16)
        Me.Label_Unit.TabIndex = 5
        Me.Label_Unit.Text = "Unit"
        '
        'GrpExchange
        '
        Me.GrpExchange.Controls.Add(Me.GrpShowAs)
        Me.GrpExchange.Controls.Add(Me.TextBox_Unit)
        Me.GrpExchange.Controls.Add(Me.TextBox_RegAddress)
        Me.GrpExchange.Controls.Add(Me.Label_Size)
        Me.GrpExchange.Controls.Add(Me.Label_RegAddress)
        Me.GrpExchange.Controls.Add(Me.TextBox_Size)
        Me.GrpExchange.Controls.Add(Me.Label_Unit)
        Me.GrpExchange.Controls.Add(Me.Button_Run)
        Me.GrpExchange.Controls.Add(Me.Button_Read)
        Me.GrpExchange.Location = New System.Drawing.Point(12, 76)
        Me.GrpExchange.Name = "GrpExchange"
        Me.GrpExchange.Size = New System.Drawing.Size(417, 237)
        Me.GrpExchange.TabIndex = 10
        Me.GrpExchange.TabStop = False
        Me.GrpExchange.Text = "Data exchange"
        Me.GrpExchange.Visible = False
        '
        'GrpShowAs
        '
        Me.GrpShowAs.Controls.Add(Me.radChar)
        Me.GrpShowAs.Controls.Add(Me.radBits)
        Me.GrpShowAs.Controls.Add(Me.radWord)
        Me.GrpShowAs.Controls.Add(Me.radBytes)
        Me.GrpShowAs.Location = New System.Drawing.Point(10, 42)
        Me.GrpShowAs.Name = "GrpShowAs"
        Me.GrpShowAs.Size = New System.Drawing.Size(91, 123)
        Me.GrpShowAs.TabIndex = 9
        Me.GrpShowAs.TabStop = False
        Me.GrpShowAs.Text = "Show as"
        '
        'radChar
        '
        Me.radChar.AutoSize = True
        Me.radChar.Enabled = False
        Me.radChar.Location = New System.Drawing.Point(24, 91)
        Me.radChar.Name = "radChar"
        Me.radChar.Size = New System.Drawing.Size(46, 16)
        Me.radChar.TabIndex = 3
        Me.radChar.Text = "Char"
        Me.radChar.UseVisualStyleBackColor = True
        '
        'radBits
        '
        Me.radBits.AutoSize = True
        Me.radBits.Enabled = False
        Me.radBits.Location = New System.Drawing.Point(24, 22)
        Me.radBits.Name = "radBits"
        Me.radBits.Size = New System.Drawing.Size(41, 16)
        Me.radBits.TabIndex = 0
        Me.radBits.Text = "Bits"
        Me.radBits.UseVisualStyleBackColor = True
        '
        'radWord
        '
        Me.radWord.AutoSize = True
        Me.radWord.Location = New System.Drawing.Point(24, 68)
        Me.radWord.Name = "radWord"
        Me.radWord.Size = New System.Drawing.Size(50, 16)
        Me.radWord.TabIndex = 2
        Me.radWord.Text = "Word"
        Me.radWord.UseVisualStyleBackColor = True
        '
        'radBytes
        '
        Me.radBytes.AutoSize = True
        Me.radBytes.Enabled = False
        Me.radBytes.Location = New System.Drawing.Point(24, 44)
        Me.radBytes.Name = "radBytes"
        Me.radBytes.Size = New System.Drawing.Size(49, 16)
        Me.radBytes.TabIndex = 1
        Me.radBytes.Text = "Bytes"
        Me.radBytes.UseVisualStyleBackColor = True
        '
        'GrpComm
        '
        Me.GrpComm.Controls.Add(Me.TextBox_IP)
        Me.GrpComm.Controls.Add(Me.Label_IP)
        Me.GrpComm.Controls.Add(Me.Button_Connect)
        Me.GrpComm.Controls.Add(Me.TextBox_ID)
        Me.GrpComm.Controls.Add(Me.Label_ID)
        Me.GrpComm.Location = New System.Drawing.Point(12, 12)
        Me.GrpComm.Name = "GrpComm"
        Me.GrpComm.Size = New System.Drawing.Size(417, 58)
        Me.GrpComm.TabIndex = 11
        Me.GrpComm.TabStop = False
        Me.GrpComm.Text = "Communication"
        '
        'GrpData
        '
        Me.GrpData.Location = New System.Drawing.Point(435, 12)
        Me.GrpData.Name = "GrpData"
        Me.GrpData.Size = New System.Drawing.Size(487, 301)
        Me.GrpData.TabIndex = 12
        Me.GrpData.TabStop = False
        Me.GrpData.Text = "Data"
        Me.GrpData.Visible = False
        '
        'ModbusConnect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(934, 325)
        Me.Controls.Add(Me.GrpData)
        Me.Controls.Add(Me.GrpComm)
        Me.Controls.Add(Me.GrpExchange)
        Me.Name = "ModbusConnect"
        Me.Text = "ModbusConnect"
        Me.GrpExchange.ResumeLayout(False)
        Me.GrpExchange.PerformLayout()
        Me.GrpShowAs.ResumeLayout(False)
        Me.GrpShowAs.PerformLayout()
        Me.GrpComm.ResumeLayout(False)
        Me.GrpComm.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TextBox_IP As TextBox
    Friend WithEvents Label_IP As Label
    Friend WithEvents TextBox_ID As TextBox
    Friend WithEvents Label_ID As Label
    Friend WithEvents TextBox_RegAddress As TextBox
    Friend WithEvents Label_RegAddress As Label
    Friend WithEvents Button_Read As Button
    Friend WithEvents Button_Run As Button
    Friend WithEvents TextBox_Size As TextBox
    Friend WithEvents Label_Size As Label
    Friend WithEvents Button_Connect As Button
    Friend WithEvents TextBox_Unit As TextBox
    Friend WithEvents Label_Unit As Label
    Friend WithEvents GrpExchange As GroupBox
    Friend WithEvents GrpComm As GroupBox
    Friend WithEvents GrpData As GroupBox

    Friend WithEvents radBits As RadioButton
    Friend WithEvents radChar As RadioButton
    Friend WithEvents radWord As RadioButton
    Friend WithEvents radBytes As RadioButton
    Friend WithEvents GrpShowAs As GroupBox
End Class
